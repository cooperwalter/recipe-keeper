(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__4349a9b2._.css",
  "static/chunks/97880_@tanstack_query-devtools_build_1c9369b5._.js",
  "static/chunks/node_modules__pnpm_8d60575c._.js",
  "static/chunks/_dc5b90bc._.js"
],
    source: "dynamic"
});
