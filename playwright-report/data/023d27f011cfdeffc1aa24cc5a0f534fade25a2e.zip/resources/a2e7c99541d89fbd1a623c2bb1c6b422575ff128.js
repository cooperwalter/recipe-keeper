(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/07552_@supabase_node-fetch_browser_aad48d54.js",
  "static/chunks/_5cc740b3._.js",
  "static/chunks/node_modules__pnpm_fc70fd3f._.js"
],
    source: "dynamic"
});
